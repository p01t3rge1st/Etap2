var searchData=
[
  ['interpretationframe_0',['interpretationFrame',['../classMainWindow.html#a2bd04a297fbb80636c9b3d6755768c77',1,'MainWindow']]]
];
