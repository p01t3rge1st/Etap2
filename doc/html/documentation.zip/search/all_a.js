var searchData=
[
  ['ontimemachinechanged_0',['onTimeMachineChanged',['../classMainWindow.html#a392e2293bb3029e841ef8cc11a16b059',1,'MainWindow']]],
  ['openport_1',['openPort',['../classSensorReader.html#a670969b9b0611931a942cb9fc887b66d',1,'SensorReader']]]
];
