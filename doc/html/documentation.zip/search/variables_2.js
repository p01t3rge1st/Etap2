var searchData=
[
  ['chart_0',['chart',['../classMainWindow.html#a6743baa254d0125c329c4f2bef3bb866',1,'MainWindow']]],
  ['chartselector_1',['chartSelector',['../classMainWindow.html#a1f374fc687c402c67330728334069e1b',1,'MainWindow']]],
  ['chartstarttime_2',['chartStartTime',['../classMainWindow.html#af5c0498df5769d4ec484223f437b5dad',1,'MainWindow']]],
  ['chartview_3',['chartView',['../classMainWindow.html#aa8cf119eb52ae432d2bd2f5b55750de1',1,'MainWindow']]],
  ['co2_4',['co2',['../structSensorData.html#aa08cd2414f3df2746db49a08abcd8ca4',1,'SensorData']]],
  ['co2_5fhum_5',['co2_hum',['../structSensorData.html#a88bd3f71f5a66feb1cff2bcd437471ef',1,'SensorData']]],
  ['co2_5ftemp_6',['co2_temp',['../structSensorData.html#aa86daf30538726c1188bfe8a928107a0',1,'SensorData']]],
  ['co2humlabel_7',['co2HumLabel',['../classMainWindow.html#a721d5be1566c8200ece55112bb3b597d',1,'MainWindow']]],
  ['co2label_8',['co2Label',['../classMainWindow.html#a43e1877abcc5674c6abeaa06f51f0e9b',1,'MainWindow']]],
  ['co2series_9',['co2Series',['../classMainWindow.html#a3f441ed01f4b3420cdb556046c3923be',1,'MainWindow']]],
  ['co2statuslabel_10',['co2StatusLabel',['../classMainWindow.html#aa0d573a8981cf69c771704a600c1d343',1,'MainWindow']]],
  ['co2templabel_11',['co2TempLabel',['../classMainWindow.html#a1381d00c3189554fc80656f5a22c82f2',1,'MainWindow']]],
  ['cps_5fper_5fusv_12',['CPS_PER_USV',['../MainWindow_8cpp.html#a5bcc10879d1449723fc4dc5ca1643b01',1,'CPS_PER_USV():&#160;MainWindow.cpp'],['../SensorDataLogger_8cpp.html#a5bcc10879d1449723fc4dc5ca1643b01',1,'CPS_PER_USV():&#160;SensorDataLogger.cpp']]],
  ['crc_13',['crc',['../structSensorData.html#a5500b2c6f1b625887e5e3413dbf8913b',1,'SensorData']]],
  ['crcvalid_14',['crcValid',['../structSensorData.html#a935003bce70efb3b24a11506b0b4d649',1,'SensorData']]]
];
