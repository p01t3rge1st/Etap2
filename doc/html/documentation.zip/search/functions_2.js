var searchData=
[
  ['loadhistoricaldata_0',['loadHistoricalData',['../classMainWindow.html#aaf30da4e1a1a3b097f20cdfaa532eff4',1,'MainWindow']]],
  ['log_1',['log',['../classSensorDataLogger.html#a22ec6b9a47578f9be3b2771d3fa269c1',1,'SensorDataLogger']]]
];
