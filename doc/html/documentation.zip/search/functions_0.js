var searchData=
[
  ['calculatecrc_0',['calculateCRC',['../classSensorReader.html#a0a0ddf7eae30439740b91f9a6fc45f5d',1,'SensorReader']]],
  ['changelanguage_1',['changeLanguage',['../classMainWindow.html#a9e0dd54aecbe2e3af6306c3a005d43d2',1,'MainWindow']]],
  ['closeport_2',['closePort',['../classSensorReader.html#a7f365e79bdc97851dcdbba40f4888335',1,'SensorReader']]]
];
