var searchData=
[
  ['sensordataframe_0',['sensorDataFrame',['../classMainWindow.html#a1f192e91c85da80a77d8d0d5f8c41802',1,'MainWindow']]],
  ['sensorreader_1',['sensorReader',['../classMainWindow.html#abd962b3c08fd77f6af8840c9fad9380c',1,'MainWindow']]],
  ['serial_5fdata_2',['serial_data',['../classSensorReader.html#aaae035aa78b5295e55aece9cf1a306f8',1,'SensorReader']]],
  ['serial_5fport_3',['serial_port',['../classSensorReader.html#a00637d82d16cfaf25a9e7b7a4cefbff6',1,'SensorReader']]],
  ['stream_4',['stream',['../classSensorDataLogger.html#a7c270a31078cf7de8e4850ebbb0859b5',1,'SensorDataLogger']]]
];
