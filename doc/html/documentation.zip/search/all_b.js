var searchData=
[
  ['parsesensordata_0',['parseSensorData',['../classSensorReader.html#a388472b707a086a7e0055d401c3b3e8b',1,'SensorReader']]],
  ['pm1_1',['pm1',['../structSensorData.html#a4bbb4abfde06e739b58282164b52854b',1,'SensorData']]],
  ['pm10_2',['pm10',['../structSensorData.html#aa19ba55b7fbf096d6e0d2d1bebe26a2e',1,'SensorData']]],
  ['pm10label_3',['pm10Label',['../classMainWindow.html#ab30f8af70bc84a4e56fe1dc450f4dd2b',1,'MainWindow']]],
  ['pm10series_4',['pm10Series',['../classMainWindow.html#aec3705d6726026aa720dfd05d414f97a',1,'MainWindow']]],
  ['pm1label_5',['pm1Label',['../classMainWindow.html#adef797293372990958193ee7899ac93f',1,'MainWindow']]],
  ['pm1series_6',['pm1Series',['../classMainWindow.html#a349c3b57faa5e3111599e20b57203359',1,'MainWindow']]],
  ['pm25_7',['pm25',['../structSensorData.html#a1a2ae409164ca2b9e0ae1fc6f2323221',1,'SensorData']]],
  ['pm25label_8',['pm25Label',['../classMainWindow.html#a1ab2d3578fe1cb1a975f1e5a8ec415a0',1,'MainWindow']]],
  ['pm25series_9',['pm25Series',['../classMainWindow.html#ac2286fb5d9a0e8e4b1bc23a26dc3bd3f',1,'MainWindow']]],
  ['pmstatuslabel_10',['pmStatusLabel',['../classMainWindow.html#aba1e70577afe7cc912ede6387722056d',1,'MainWindow']]],
  ['portname_11',['portname',['../classSensorReader.html#a202c307c19bb8beb21f703dcf9959641',1,'SensorReader']]],
  ['printinitstatus_12',['printInitStatus',['../main_8cpp.html#abe51fe930b9b9821ce75e6810f2877b3',1,'main.cpp']]]
];
