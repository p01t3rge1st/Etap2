var searchData=
[
  ['languageselector_0',['languageSelector',['../classMainWindow.html#aa9a1674cdd8f52bb30b208f4cbf3f2df',1,'MainWindow']]],
  ['logger_1',['logger',['../classMainWindow.html#a153dde7daa20117fae0014b0f320b0b1',1,'MainWindow']]]
];
