var searchData=
[
  ['baudrate_0',['baudrate',['../classSensorReader.html#aaebc91f52f1d25176af61212d015b5ff',1,'SensorReader']]],
  ['buffer_1',['buffer',['../classSensorReader.html#a91a682e413b5df61950b591162157518',1,'SensorReader']]]
];
