var searchData=
[
  ['sensordatalogger_0',['SensorDataLogger',['../classSensorDataLogger.html#aac2b933522c481e3a3679688b61d54b8',1,'SensorDataLogger']]],
  ['sensorreader_1',['SensorReader',['../classSensorReader.html#a6bfc52943447a48a7eab3a791bdb3b0f',1,'SensorReader']]]
];
