var searchData=
[
  ['data_0',['data',['../classSensorReader.html#ac45e464399cee627f8e155d22ffd733d',1,'SensorReader']]]
];
