var searchData=
[
  ['file_0',['file',['../classSensorDataLogger.html#ac5c443a08178e42b720875037b02747c',1,'SensorDataLogger']]]
];
