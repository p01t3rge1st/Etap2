var indexSectionsWithContent =
{
  0: "abcdfghilmoprstuw~",
  1: "ms",
  2: "mrs",
  3: "cglmoprsuw~",
  4: "abcdfhilmprst",
  5: "cgr",
  6: "s"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "files",
  3: "functions",
  4: "variables",
  5: "defines",
  6: "pages"
};

var indexSectionLabels =
{
  0: "Wszystko",
  1: "Struktury Danych",
  2: "Pliki",
  3: "Funkcje",
  4: "Zmienne",
  5: "Definicje",
  6: "Strony"
};

