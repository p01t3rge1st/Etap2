var searchData=
[
  ['axisx_0',['axisX',['../classMainWindow.html#a39e350c55fc0ec85cff76342161d86be',1,'MainWindow']]],
  ['axisy_1',['axisY',['../classMainWindow.html#aa53ae2baadd07e2bbe0cbcfd0cf27dbf',1,'MainWindow']]]
];
