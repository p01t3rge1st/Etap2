var searchData=
[
  ['getdata_0',['getData',['../classSensorReader.html#a1d6e6a16ca1726b2b563bd125fe9f15e',1,'SensorReader']]]
];
