var searchData=
[
  ['languageselector_0',['languageSelector',['../classMainWindow.html#aa9a1674cdd8f52bb30b208f4cbf3f2df',1,'MainWindow']]],
  ['loadhistoricaldata_1',['loadHistoricalData',['../classMainWindow.html#aaf30da4e1a1a3b097f20cdfaa532eff4',1,'MainWindow']]],
  ['log_2',['log',['../classSensorDataLogger.html#a22ec6b9a47578f9be3b2771d3fa269c1',1,'SensorDataLogger']]],
  ['logger_3',['logger',['../classMainWindow.html#a153dde7daa20117fae0014b0f320b0b1',1,'MainWindow']]]
];
