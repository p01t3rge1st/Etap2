var searchData=
[
  ['max_5fco2_0',['MAX_CO2',['../MainWindow_8cpp.html#ad6bf891f67bc7a84a260bc6f3d9771c1',1,'MainWindow.cpp']]],
  ['max_5fpm1_1',['MAX_PM1',['../MainWindow_8cpp.html#a3b75635c7c1c7e9ae1f0a0c2abbcc307',1,'MainWindow.cpp']]],
  ['max_5fpm10_2',['MAX_PM10',['../MainWindow_8cpp.html#a75fff52d8e7e31a914a573a803e00c8d',1,'MainWindow.cpp']]],
  ['max_5fpm25_3',['MAX_PM25',['../MainWindow_8cpp.html#a38ab099a01e4b3aa8863feedc74c54d1',1,'MainWindow.cpp']]],
  ['max_5fradiation_4',['MAX_RADIATION',['../MainWindow_8cpp.html#a47e4224bac12dee553602b8677045598',1,'MainWindow.cpp']]]
];
