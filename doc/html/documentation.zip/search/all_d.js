var searchData=
[
  ['sensordata_0',['SensorData',['../structSensorData.html',1,'']]],
  ['sensordataframe_1',['sensorDataFrame',['../classMainWindow.html#a1f192e91c85da80a77d8d0d5f8c41802',1,'MainWindow']]],
  ['sensordatalogger_2',['SensorDataLogger',['../classSensorDataLogger.html',1,'SensorDataLogger'],['../classSensorDataLogger.html#aac2b933522c481e3a3679688b61d54b8',1,'SensorDataLogger::SensorDataLogger()']]],
  ['sensordatalogger_2ecpp_3',['SensorDataLogger.cpp',['../SensorDataLogger_8cpp.html',1,'']]],
  ['sensordatalogger_2eh_4',['SensorDataLogger.h',['../SensorDataLogger_8h.html',1,'']]],
  ['sensorreader_5',['SensorReader',['../classSensorReader.html',1,'SensorReader'],['../classSensorReader.html#a6bfc52943447a48a7eab3a791bdb3b0f',1,'SensorReader::SensorReader()']]],
  ['sensorreader_6',['sensorReader',['../classMainWindow.html#abd962b3c08fd77f6af8840c9fad9380c',1,'MainWindow']]],
  ['sensorreader_2ecpp_7',['SensorReader.cpp',['../SensorReader_8cpp.html',1,'']]],
  ['sensorreader_2eh_8',['SensorReader.h',['../SensorReader_8h.html',1,'']]],
  ['serial_5fdata_9',['serial_data',['../classSensorReader.html#aaae035aa78b5295e55aece9cf1a306f8',1,'SensorReader']]],
  ['serial_5fport_10',['serial_port',['../classSensorReader.html#a00637d82d16cfaf25a9e7b7a4cefbff6',1,'SensorReader']]],
  ['stream_11',['stream',['../classSensorDataLogger.html#a7c270a31078cf7de8e4850ebbb0859b5',1,'SensorDataLogger']]],
  ['system_20monitorowania_20czujników_12',['System Monitorowania Czujników',['../index.html',1,'']]]
];
