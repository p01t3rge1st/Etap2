var searchData=
[
  ['temperatureseries_0',['temperatureSeries',['../classMainWindow.html#aa03bb901ea7cbd58fb3cbfc6bc11cf55',1,'MainWindow']]],
  ['timemachinegroup_1',['timeMachineGroup',['../classMainWindow.html#ae2d3f55c0d919823be32d5b5a1279304',1,'MainWindow']]],
  ['timemachinehours_2',['timeMachineHours',['../classMainWindow.html#a916799760788361dfc8c072b1b551bea',1,'MainWindow']]],
  ['timer_3',['timer',['../classMainWindow.html#a356578805ed1248a7f2807434cb0e5ee',1,'MainWindow']]],
  ['translator_4',['translator',['../classMainWindow.html#a8e829b3590ccdeeada42625415afc6f3',1,'MainWindow']]],
  ['tvoc_5',['tvoc',['../structSensorData.html#a7085f9e57a09ef9d21d186f63d81a28a',1,'SensorData']]]
];
