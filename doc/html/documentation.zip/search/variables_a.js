var searchData=
[
  ['radiation_0',['radiation',['../structSensorData.html#aea39d17cc6edacb767c63708e4650cbc',1,'SensorData']]],
  ['radiation_5fdose_5fper_5fhour_1',['radiation_dose_per_hour',['../structSensorData.html#a6b9fb45f05c03bd6c2d5a81b94a09afc',1,'SensorData']]],
  ['radiationdoselabel_2',['radiationDoseLabel',['../classMainWindow.html#a686e05093351bd0c45fa60cda8070b13',1,'MainWindow']]],
  ['radiationdoseseries_3',['radiationDoseSeries',['../classMainWindow.html#aaec3095696451b86ee94346f2613f5cc',1,'MainWindow']]],
  ['radiationlabel_4',['radiationLabel',['../classMainWindow.html#ab8ca484526c571403d029aeaa75e6427',1,'MainWindow']]],
  ['radiationseries_5',['radiationSeries',['../classMainWindow.html#a4c211e23002dbc4c6a4cf5d40148fd2c',1,'MainWindow']]],
  ['radiationstatuslabel_6',['radiationStatusLabel',['../classMainWindow.html#a4cd27ff37e219f9728698e056da8afc6',1,'MainWindow']]]
];
