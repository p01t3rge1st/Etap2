var searchData=
[
  ['updatecharttitles_0',['updateChartTitles',['../classMainWindow.html#accc74af8b6dbd54ee872a789986ba72f',1,'MainWindow']]],
  ['updateinterfacetexts_1',['updateInterfaceTexts',['../classMainWindow.html#a6c022bdf4b08d56f3ba53484c0a4cbb2',1,'MainWindow']]],
  ['updatesensordata_2',['updateSensorData',['../classMainWindow.html#a2e5dc7b198af26e0ecd559fb5ca6cc5d',1,'MainWindow']]]
];
