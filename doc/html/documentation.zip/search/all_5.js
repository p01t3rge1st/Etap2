var searchData=
[
  ['getdata_0',['getData',['../classSensorReader.html#a1d6e6a16ca1726b2b563bd125fe9f15e',1,'SensorReader']]],
  ['green_1',['GREEN',['../main_8cpp.html#acfbc006ea433ad708fdee3e82996e721',1,'main.cpp']]]
];
